package edu.miracosta.cs112.lab8;

//IMPORTED PACKAGES
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Background;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.ProgressBar;
import javafx.geometry.Pos;
import javafx.scene.control.Tooltip;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.paint.Color;
public class Main extends Application {
    //CONSTANTS
    private static final LoteriaCard[] LOTERIA_CARDS = {
            new LoteriaCard("Las matematicas", "1.png", 1),
            new LoteriaCard("Las ciencias", "2.png", 2),
            new LoteriaCard("La Tecnología", "8.png", 8),
            new LoteriaCard("La ingeniería", "9.png", 9),
    };

    //CLASS-LEVEL VARIABLES


    //GUI METHODS
    private Label titleLabel;
    private ImageView cardImageView;
    private Label messageLabel;
    private Button drawCardButton;
    private ProgressBar gameProgressBar;
    public static void main(String[] args) {
        launch(args);
    }
    int count = 0;
    @Override
    public void start(Stage primaryStage) throws Exception {

        Image image = new LoteriaCard().getImage();
        titleLabel = new Label("Welcome to EChALE STEM Loteria");
        titleLabel.setFont(Font.font("", FontWeight.BOLD, 20));
        cardImageView = new ImageView();
        cardImageView.setImage(image);
        //563 by 713
        cardImageView.setFitWidth(290);
        cardImageView.setFitHeight(360);
        messageLabel = new Label(" Click the button below to randomly draw a card. The\nprogress bar will indicate how far we're into the game.");
        drawCardButton = new Button("Draw Random Card");
        gameProgressBar = new ProgressBar(0);
        drawCardButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                count++; //MAKE IT SO THAT THE CARDS CHOSEN ARE RANDOM WITHOUT REPEATS
                if (count <= LOTERIA_CARDS.length){
                    Image newimage = LOTERIA_CARDS[count-1].getImage();
                    cardImageView.setImage(newimage);
                    messageLabel.setText(LOTERIA_CARDS[count-1].getCardName() + "\n ");
                    gameProgressBar.setProgress(0.25 * count);
                } else{
                    messageLabel.setText("      GAME OVER. No more cards! \nExit and run program again to reset ^_^");
                    cardImageView.setImage(image);
                    drawCardButton.setDisable(true);
                    gameProgressBar.setStyle("-fx-accent: red");

                }

            };
        });

        VBox layout = new VBox();
        layout.getChildren().add(titleLabel);
        layout.getChildren().add(cardImageView);
        layout.getChildren().add(messageLabel);
        layout.getChildren().add(drawCardButton);
        layout.getChildren().add(gameProgressBar);
        layout.setAlignment(Pos.CENTER);

        Scene primaryScene = new Scene(layout, 350, 500);
        primaryStage.setScene(primaryScene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("EChALE STEM Loteria");
        primaryStage.show();


    }
}