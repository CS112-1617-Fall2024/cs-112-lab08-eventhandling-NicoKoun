module edu.miracosta.cs112.lab8 {
    requires javafx.controls;
    requires javafx.fxml;


    opens edu.miracosta.cs112.lab8 to javafx.fxml;
    exports edu.miracosta.cs112.lab8;
}